package com.example.jota.ugr;

import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;

/*
En esta clase definimos los distintos tipos de filtros de busqueda que tendremos.
 */
public class SearchFilters {
    /*
    Inicialmente tendremos definimos 2 filtros para futura ampliación:
    - Relevancia, cuanta mayor antes será mostrada.
    - Fecha, cuanto más actual antes será mostrada.
     */
    private int myFilter;

    public SearchFilters(){
        this.myFilter=0;
    }

    public int getMyFilter() {
        return myFilter;
    }

    public void setMyFilter(int m) {
        if( (m >= 0) && (m <= 2) ) {
            this.myFilter = m;
        }else {
            this.myFilter = 0;
        }
    }

    /*
    Metodo de ordenación para los filtros
     */
    public ArrayList<News> SortByFilter(ArrayList<News> l){
        if(this.myFilter == 0){ //RELEVANCIA
            for(int i = 0 ; i < l.size()-1 ; i++ ) {
                int rmin = l.get(i).getRelevancia();
                for(int j=i+1; j<l.size() ; j++) {
                    if(l.get(j).getRelevancia() > rmin)
                        Collections.swap(l,i,j);
                }
            }
        }
        else if(this.myFilter == 1){ //De más lejana a más cercana
            for(int i = 0 ; i < l.size()-1 ; i++) {

                Calendar aux = l.get(i).getCalendar();

                for(int j=i+1; j<l.size() ; j++) {
                    if( aux.compareTo(l.get(j).getCalendar()) > 0){  // 0 son iguales
                        Collections.swap(l,i,j);                     // x<0 (aux < l.get(i)) ; x>0 (aux > l.get(i))
                    }
                }
            }

        }
        else if(this.myFilter == 2){ //De más cercana a más lejana
            for(int i = 0 ; i < l.size()-1 ; i++) {
                Calendar aux = l.get(i).getCalendar();

                for(int j=i+1; j<l.size() ; j++) {

                    if( aux.compareTo(l.get(j).getCalendar()) < 0){  // 0 son iguales
                        Collections.swap(l,i,j);                     // x<0 (aux < l.get(i)) ; x>0 (aux > l.get(i))
                    }

                }
            }

        }

        return l;
    }

    public ArrayList<News> SortByTag(ArrayList<News> l, String tag){

        ArrayList<News> ln = new ArrayList<News>();
        for(int position = 0 ; position < l.size() ; position++){

            Collection<String> etiqetas = l.get(position).getMyTarget().values();
            for(String item:etiqetas){
                if(l.get(position).getMyTarget().containsValue(tag))
                    ln.add(l.get(position));
            }

        }

        return ln;
    }

}
