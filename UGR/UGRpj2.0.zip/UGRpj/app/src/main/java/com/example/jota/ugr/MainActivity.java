package com.example.jota.ugr;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private ListView myListView;
    private Adapter adapter;
    ArrayList<News> nv;
    private SearchFilters myFilter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nv = new ArrayList<>();
        myFilter = new SearchFilters(); //Por defecto se ordena por relevancia
        //Seleccionamos el tipo de filtro que queremos
        this.myFilter.setMyFilter(1);

        Calendar au = Calendar.getInstance();
        Calendar ua = Calendar.getInstance();

        au.set(1002,10,10);
        ua.set(1001,10,10);
        System.out.println(au.compareTo(ua));

        News n = new News();
        n.setNombre("Titulo 1");
        n.setDescripcion("Descripcion 1");
        n.setOrganizador("hola hola hola hola");
        n.setCalendar(2018,12,10);
        n.setRelevancia(1);
        n.setMyTarget("Primera","Primera etiqueta");
        n.setMyTarget("Segunda","Segunda etiqueta");
        nv.add(n);

        n = new News();
        n.setNombre("Titulo 2");
        n.setDescripcion("Descripcion 2");
        n.setCalendar(2018,12,1);
        n.setRelevancia(2);
        n.setMyTarget("Tercera","Tercera etiqueta");
        n.setMyTarget("Cuarta","Cuarta etiqueta");
        nv.add(n);

        n = new News();
        n.setNombre("Titulo 3");
        n.setDescripcion("Descripcion 3234");
        n.setCalendar(2017,12,14);
        n.setRelevancia(3);
        n.setMyTarget("Quinta","Quinta etiqueta");
        n.setMyTarget("Primera","Sexta etiqueta");
        nv.add(n);

        //Aplicamos filtro de ordenación
        //this.nv = myFilter.SortByFilter(nv);

        //Aplicamos filtro por tags
        this.nv = myFilter.SortByTag(nv,"Primera");

        adapter = new MyAdapter(this,nv);

        myListView = (ListView)findViewById(R.id.myLV);
        myListView.setAdapter((ListAdapter) adapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
                Object item = adapter.getItemAtPosition(position);
                News noticia = nv.get(position);

                Gson g = new Gson();
                String json = g.toJson(noticia);

                Intent intent = new Intent(MainActivity.this , NewView.class );
                intent.putExtra("data",json);


                startActivity(intent);
            }
        });
    }


}
