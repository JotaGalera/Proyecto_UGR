package com.example.jota.ugr;

import java.util.HashMap;
import java.util.Map;

public class TargetNews {

    private Map<String,String> target = new HashMap<String, String>();

    public TargetNews(){
        Map<String,String> target = new HashMap<String, String>();
    }

    public void setTargetNews(String a,String s){
        target.put(a,s);
    }

    public Map<String,String> getTargetNews(){
        return target;
    }

}
