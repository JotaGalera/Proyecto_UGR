package com.example.jota.ugr;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.google.gson.Gson;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView myListView;
    private Adapter adapter;
    ArrayList<News> nv;
    private SearchFilters myFilter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nv = new ArrayList<>();
        myFilter = new SearchFilters(); //Por defecto se ordena por relevancia
        //Seleccionamos el tipo de filtro que queremos
        myFilter.setMyFilter(1);

        News n = new News();
        n.setNombre("Titulo 1");
        n.setDescripcion("Descripcion 1");
        n.setOrganizador("hola hola hola hola");
        n.setDia(10);
        n.setMes(12);
        n.setAnio(2018);
        n.setRelevancia(2);
        nv.add(n);

        n = new News();
        n.setNombre("Titulo 2");
        n.setDescripcion("Descripcion 2");
        n.setDia(11);
        n.setMes(12);
        n.setAnio(2018);
        n.setRelevancia(1);
        nv.add(n);

        n = new News();
        n.setNombre("Titulo 3");
        n.setDescripcion("Descripcion 3");
        n.setDia(14);
        n.setMes(12);
        n.setAnio(2018);
        n.setRelevancia(3);
        nv.add(n);

        //Aplicamos filtro de ordenación
        this.nv = myFilter.SortByFilter(nv);

        adapter = new MyAdapter(this,nv);

        myListView = (ListView)findViewById(R.id.myLV);
        myListView.setAdapter((ListAdapter) adapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
                Object item = adapter.getItemAtPosition(position);
                News noticia = nv.get(position);

                Gson g = new Gson();
                String json = g.toJson(noticia);

                Intent intent = new Intent(MainActivity.this , NewView.class );
                intent.putExtra("data",json);


                startActivity(intent);
            }
        });
    }


}
