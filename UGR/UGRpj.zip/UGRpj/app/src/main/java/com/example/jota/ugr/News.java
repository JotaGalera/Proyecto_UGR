package com.example.jota.ugr;



public class News {
    private String nombre="nombre";
    private String descripcion="descripcion";
    private String fecha="fecha";
    private int dia=0;
    private int mes=0;
    private int anio=0;
    private String organizador="organizador";
    private String participantes="participantes";

    /*
    relevancia , valor entre 0-10, un valor de filtro, con el que se podrán ordenar las noticias en
    función de la importancia que tengas estas para el centro.
    Inicialmente valdrá 0 , tal que si en algún momento alguna noticia obtiene un valor mayor aparecerá
    antes que el resto.
    Este parámetro no será mostrado, servira de forma interna.
     */
    private int relevancia = 0;



    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getOrganizador() {
        return organizador;
    }

    public void setOrganizador(String organizador) {
        this.organizador = organizador;
    }

    public String getParticipantes() {
        return participantes;
    }

    public void setParticipantes(String participantes) {
        this.participantes = participantes;
    }

    public int getRelevancia() {
        return relevancia;
    }

    public void setRelevancia(int relevancia) {
        this.relevancia = relevancia;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
}
