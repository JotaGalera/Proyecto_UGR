package com.example.jota.ugr;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;

public class NewView extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_view);

        TextView t1 = (TextView) findViewById(R.id.texName);
        TextView t2 = (TextView) findViewById(R.id.textDesc);
        TextView t3 = (TextView) findViewById(R.id.textData);
        TextView t4 = (TextView) findViewById(R.id.textorganization);
        TextView t5 = (TextView) findViewById(R.id.textUsers);

        Gson g = new Gson();

        String data = getIntent().getExtras().getString("data","defaultKey");

        News noticia = g.fromJson(data,News.class);

        t1.setText(noticia.getNombre());
        t2.setText(noticia.getDescripcion());
        t3.setText(noticia.getFecha());
        t4.setText(noticia.getOrganizador());
        t5.setText(noticia.getParticipantes());

    }

}
