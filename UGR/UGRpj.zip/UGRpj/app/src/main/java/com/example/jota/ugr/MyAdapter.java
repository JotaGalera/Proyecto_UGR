package com.example.jota.ugr;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<News> arrayList;

    public MyAdapter(Context c, ArrayList<News> array){
        this.context = c;
        this.arrayList = array;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.item,null);
        }
        TextView nombre = (TextView)convertView.findViewById(R.id.nom);
        TextView descripcion = (TextView)convertView.findViewById(R.id.desc);

        nombre.setText(arrayList.get(position).getNombre());
        descripcion.setText(arrayList.get(position).getDescripcion());
        return convertView;
    }


    /*public View getView2(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.item,null);
        }
        TextView nombre = (TextView)convertView.findViewById(R.id.texName);
        TextView descripcion = (TextView)convertView.findViewById(R.id.textData);
        TextView fecha = (TextView)convertView.findViewById(R.id.textData);
        TextView organiza = (TextView)convertView.findViewById(R.id.textorganization);
        TextView participa = (TextView)convertView.findViewById(R.id.textUsers);

        nombre.setText(arrayList.get(position).getNombre());
        descripcion.setText(arrayList.get(position).getDescripcion());
        return convertView;
    }*/
}
