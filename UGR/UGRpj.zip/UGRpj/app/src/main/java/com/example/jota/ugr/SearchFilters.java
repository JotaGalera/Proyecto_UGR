package com.example.jota.ugr;

import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/*
En esta clase definimos los distintos tipos de filtros de busqueda que tendremos.
 */
public class SearchFilters {
    /*
    Inicialmente tendremos definimos 2 filtros para futura ampliación:
    - Relevancia, cuanta mayor antes será mostrada.
    - Fecha, cuanto más actual antes será mostrada.
     */
    private int myFilter;

    public SearchFilters(){
        this.myFilter=0;
    }

    public int getMyFilter() {
        return myFilter;
    }

    public void setMyFilter(int m) {
        if(m >= 0 && m <= 2 )
            this.myFilter = myFilter;
    }

    /*
    Metodo de ordenación para los filtros
     */
    public ArrayList<News> SortByFilter(ArrayList<News> l){
        if(this.myFilter == 0){
            for(int i = 0 ; i < l.size()-1 ; i++ ) {
                int rmin = l.get(i).getRelevancia();
                for(int j=i+1; j<l.size() ; j++) {
                    if(l.get(j).getRelevancia() > rmin)
                        Collections.swap(l,i,j);
                }
            }
        }
        else if(this.myFilter == 1){ //De más lejana a más cercana
            for(int i = 0 ; i < l.size()-1 ; i++) {
                int aniomin = l.get(i).getAnio();
                int mesmin = l.get(i).getMes();
                int diamin= l.get(i).getDia();
                for(int j=i+1; j<l.size() ; j++) {
                    if(l.get(j).getAnio() > aniomin)
                        Collections.swap(l,i,j);
                    else if( (l.get(j).getAnio() == aniomin) && l.get(j).getMes() > mesmin)
                        Collections.swap(l,i,j);
                    else if( (l.get(j).getAnio() == aniomin) && (l.get(j).getMes() == mesmin) && l.get(j).getDia() > diamin )
                        Collections.swap(l,i,j);
                }
            }

        }
        else if(this.myFilter == 2){ //De más cercana a más lejana
            for(int i = 0 ; i < l.size()-1 ; i++) {
                int aniomin = l.get(i).getAnio();
                int mesmin = l.get(i).getMes();
                int diamin= l.get(i).getDia();
                for(int j=i+1; j<l.size() ; j++) {
                    if(l.get(j).getAnio() < aniomin)
                        Collections.swap(l,i,j);
                    else if( (l.get(j).getAnio() == aniomin) && l.get(j).getMes() < mesmin)
                        Collections.swap(l,i,j);
                    else if( (l.get(j).getAnio() == aniomin) && (l.get(j).getMes() == mesmin) && l.get(j).getDia() < diamin )
                        Collections.swap(l,i,j);
                }
            }

        }


        return l;
    }


}
